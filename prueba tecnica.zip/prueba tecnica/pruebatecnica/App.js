import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { useEffect, useState } from "react";
import Home from "./Pages/Home";
import Header from "./components/Header";
import { auth } from "./firebase";
import { useDispatch, useSelector } from "react-redux";
import { login, logout, selectUser } from "./features/UserSlice";

function App() {
  const user = useSelector(selectUser);
  const classes = useStyles();
  const dispatch = useDispatch();
}{


    return unsubscribe;
  }, [dispatch]);

   return (
    <div className={classes.root}>    

    <Router>
           <Routes>
            <Route path="/" element={<Home />} />
          </Routes>
    </Router>
    </div>  
    );   
}

const useStyles = makeStyles((theme) => ({
  root: {
     minHeight: "100vh",
     backgroundColor: "#111"
  },
})) }

export default MovieApp;

