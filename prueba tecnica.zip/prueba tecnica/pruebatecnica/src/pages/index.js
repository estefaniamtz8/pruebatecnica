import React from 'react';
import { StyleSheet, View, Text, FlatList } from 'react-native';

const data = [
 { id: 1, title: 'Movies', description: 'peliculas populares' },
  { id: 2, title: 'Series', description: 'Series populares' },
 
];

const MovieApp = () => {
  const renderMovie = ({ item }) => (
    <View style={styles.movieCard}>
      <Text style={styles.movieTitle}>{item.title}</Text>
      <Text style={styles.movieDescription}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Demo Streaming </Text>
      </View>
      <FlatList
        data={data}
        renderItem={renderMovie}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2} 
      />
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}> </Text>
      </View>
      <FlatList
      />
    </View>

    
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 10,
  },
  titleContainer: {
    backgroundColor: '#2196f3',
    padding: 10,
    marginBottom: 10,
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  movieCard: {
    backgroundColor: '#cfd8dc',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flex: 1,
    margin: 5,
  },
  movieTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2196f3',
  },
  movieDescription: {
    fontSize: 16,
    color: '#424242',
  },
});

export default MovieApp;