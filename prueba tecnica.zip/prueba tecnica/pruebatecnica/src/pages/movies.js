import React from 'react';
import { StyleSheet, View, Text, FlatList } from 'react-native';

const data = [
 { id: 1, title: 'Pelicula 1', description: 'Descripción de la película ' },
  { id: 2, title: 'Pelicula 2', description: 'Descripción de la película ' },
  { id: 3, title: 'Pelicula 3', description: 'Descripción de la película ' },
   {id: 4, title: 'Pelicula 4', description: 'Descripción de la película ' },
   { id: 5, title: 'Pelicula 2', description: 'Descripción de la película ' },
  { id: 6, title: 'Pelicula 3', description: 'Descripción de la película ' },
  { id: 7, title: 'Pelicula 2', description: 'Descripción de la película ' },
  { id: 8, title: 'Pelicula 3', description: 'Descripción de la película ' },
  { id: 9, title: 'Pelicula 2', description: 'Descripción de la película ' },
  { id: 10, title: 'Pelicula 3', description: 'Descripción de la película ' },
  
];

const MovieApp = () => {
  const renderMovie = ({ item }) => (
    <View style={styles.movieCard}>
      <Text style={styles.movieTitle}>{item.title}</Text>
      <Text style={styles.movieDescription}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}> Movies</Text>
      </View>
      
      <FlatList
        data={data}
        renderItem={renderMovie}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
      />
       <View style={styles.titleContainer}>
        <Text style={styles.titleText}> </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 10,
  },
  titleContainer: {
    backgroundColor: '#2196f3',
    padding: 10,
    marginBottom: 10,
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  movieCard: {
    backgroundColor: '#cfd8dc',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flex: 1,
    margin: 5,
  },
  movieTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2196f3',
  },
  movieDescription: {
    fontSize: 16,
    color: '#424242',
  },
});

export default MovieApp;