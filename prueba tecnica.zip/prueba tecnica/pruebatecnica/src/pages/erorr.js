import React from 'react';
import { StyleSheet, View, Text, FlatList } from 'react-native';

const data = [
 { id: 1, title: 'ooops, someting went wrong...' },
 
  
];

const MovieApp = () => {
  const renderMovie = ({ item }) => (
    <View style={styles.movieCard}>
      <Text style={styles.movieTitle}>{item.title}</Text>
      <Text style={styles.movieDescription}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Text style={styles.titleText}> Series</Text>
      </View>
       <View style={styles.titleContainer}>
        <Text style={styles.titleText}> Popular titles</Text>
      </View>
      
      <FlatList
        data={data}
        renderItem={renderMovie}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
      />
       <View style={styles.titleContainer}>
        <Text style={styles.titleText}> </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 10,
  },
  titleContainer: {
    backgroundColor: '#2196f3',
    padding: 8,
    marginBottom: 10,
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  movieCard: {
    backgroundColor: '#cfd8dc',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flex: 1,
    margin: 5,
  },
  movieTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#2196f3',
  },
  movieDescription: {
    fontSize: 16,
    color: '#424242',
  },
});

export default MovieApp;