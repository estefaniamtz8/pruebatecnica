import React from "react";
import { Button, makeStyles, Typography } from "@material-ui/core";
import HeroBanner from "../images/The-Witcher-DemoStreaming.jpg";
import { useEffect, useState } from "react";
import axios from "axios";
import requests from "../Request"; 

const Banner = () => {
    const classes = useStyles();
    const [movie, setMovie] = useState([]);

    const truncate = (string, n) => string?.length > n ? `${string.substr(0, n - 1)} ...` : string;

    useEffect(() => {
        const fetchData = async () => {
            const request = await axios.get(requests.fetchDemoStreamingOriginals);      
            const random = Math.floor(Math.random()* request.data.results.length - 1);
            setMovie(request.data.results[random]);
            return request;
        };
        fetchData()  
    }, [])


    return (
        <div className={classes.root}
        style={{
            backgroundImage: `url("https://image.tmdb.org/t/p/original/${movie?.backdrop_path}")`,

        }}
        >
            <div className={classes.content}>
                <Typography 
                variant="h2"
                component="h1"
                >
                    {
                        movie?.title || movie?.name || movie?.original_name
                    }
                </Typography>
                <div className={classes.buttons}>
                    <Button className={classes.button}>Play</Button>
                    
                </div>
                <Typography 
                style={{wordWrap: "break-word"}}
                variant="h6"
                className={classes.description}
                >
                    {
                        truncate(movie?.overview, 160)
                    }
                </Typography>
                <div className={classes.fadeBottom}></div>
            </div>            
        </div>
    )
}

const useStyles = makeStyles((theme) => ({
    root: {
        position: "relative",
        height: "440px",
        objectFit: "contain",
        backgroundSize: "cover",
        backgroundPosition: "center",
        color: "#fff",
    },
    content: {
        marginLeft: theme.spacing(4),
        paddingTop: theme.spacing(16),
        "& h2": {
            fontWeight: 800,
            paddingBottom: theme.spacing(3),
        },
    },
    buttons: {
        "& button": {
            cursor: "pointer",
            color: "#fff",
            fontWeight: 700,
            borderRadius: "5px",
            padding: theme.spacing(1,4,1,4),
            marginRight: "1rem",
            backgroundColor: "#2196f3", // Azul
        },
        "& button:hover": {
            color: "#000",
            backgroundColor: "#424242", // Gris oscuro
        },
    },
    button: {
        color: "#fff",
        fontWeight: 700,
        borderRadius: "5px",
        padding: theme.spacing(1,4,1,4),
        marginRight: "1rem",
        backgroundColor: "#2196f3", 
        "&:hover": {
            color: "#000",
            backgroundColor: "#424242", 
        },
    },
    description: {
        marginTop: theme.spacing(5),
        width: "45rem",
        lineHeight: "1.3",
        maxWidth: "380px",
        height: "80px",
    },
    fadeBottom: {
        position: "absolute",
        top: "30vh",
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 99,
        backgroundImage: "linear-gradient(180deg, transparent, rgba(37,37,37, 0.61), #111)",
    }
  })) 

export default Banner;
